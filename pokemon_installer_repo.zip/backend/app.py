import os, time
from flask import Flask, request, jsonify, send_file
import requests
from pathlib import Path
from io import BytesIO
import sqlite3, json as _json

app = Flask(__name__, static_folder='static', static_url_path='/static')

# Read TCG keys from config file (config.json) or environment variables
TCG_PUBLIC_KEY = os.environ.get('TCG_PUBLIC_KEY')
TCG_PRIVATE_KEY = os.environ.get('TCG_PRIVATE_KEY')
CONFIG_PATH = Path('config.json')

if CONFIG_PATH.exists():
    try:
        cfg = _json.loads(CONFIG_PATH.read_text())
        TCG_PUBLIC_KEY = TCG_PUBLIC_KEY or cfg.get('TCG_PUBLIC_KEY')
        TCG_PRIVATE_KEY = TCG_PRIVATE_KEY or cfg.get('TCG_PRIVATE_KEY')
    except Exception:
        pass

@app.route('/health')
def health():
    return jsonify({'ok':True})

@app.route('/api/hello')
def hello():
    return jsonify({'msg':'Hello from backend'})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)
