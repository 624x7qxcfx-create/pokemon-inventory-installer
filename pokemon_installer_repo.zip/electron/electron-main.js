const { app, BrowserWindow } = require('electron')
const path = require('path')
const { spawn } = require('child_process')

let backendProc = null
function startBackend() {
  const exePath = path.join(process.resourcesPath, 'backend', 'tcg_backend.exe')
  backendProc = spawn(exePath, [], { windowsHide: true })
  backendProc.stdout?.on('data', d => console.log('[backend]', d.toString()))
  backendProc.stderr?.on('data', d => console.error('[backend]', d.toString()))
}

function createWindow () {
  const win = new BrowserWindow({ width:1200, height:820, webPreferences:{nodeIntegration:false} })
  win.loadURL('http://127.0.0.1:5000')
}

app.whenReady().then(() => {
  startBackend()
  setTimeout(createWindow, 1500)
})

app.on('before-quit', () => { if (backendProc) backendProc.kill() })
