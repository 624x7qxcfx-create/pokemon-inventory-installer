import React from 'react';

export default function App(){
  return (
    <div style={{padding:20,fontFamily:'system-ui'}}>
      <h1>Pokémon Inventory — Demo</h1>
      <p>This is the frontend placeholder. In the real build the React app will be compiled to static files.</p>
    </div>
  );
}
